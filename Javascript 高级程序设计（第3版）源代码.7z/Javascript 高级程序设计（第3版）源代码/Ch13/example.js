function sayHi(){
    alert("hi!");
}